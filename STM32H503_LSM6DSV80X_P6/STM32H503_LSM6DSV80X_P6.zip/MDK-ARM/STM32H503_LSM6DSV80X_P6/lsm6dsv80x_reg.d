stm32h503_lsm6dsv80x_p6/lsm6dsv80x_reg.o: ..\Core\Src\lsm6dsv80x_reg.c \
  ..\Core\Inc\lsm6dsv80x_reg.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stddef.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\math.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\string.h
